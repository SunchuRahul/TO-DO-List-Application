document.addEventListener("DOMContentLoaded", function() {
    loadTasks();
});

function loadTasks() {
    const taskList = document.getElementById("task-list");
    taskList.innerHTML = "";

    const tasks = getTasks();

    tasks.forEach(function(task, index) {
        addTaskToDOM(task, index);
    });
}

function addTask() {
    const newTaskInput = document.getElementById("new-task");
    const newTaskText = newTaskInput.value.trim();

    if (newTaskText !== "") {
        const tasks = getTasks();
        tasks.push({ text: newTaskText });
        saveTasks(tasks);
        addTaskToDOM({ text: newTaskText }, tasks.length - 1);
        newTaskInput.value = "";
    }
}

function addTaskToDOM(task, index) {
    const taskList = document.getElementById("task-list");
    const newTask = document.createElement("li");
    newTask.className = "task";
    newTask.innerHTML = `
        <span>${task.text}</span>
        <button onclick="deleteTask(${index})">Delete</button>
    `;
    taskList.appendChild(newTask);
}

function deleteTask(index) {
    const tasks = getTasks();
    tasks.splice(index, 1);
    saveTasks(tasks);
    loadTasks();
}

function getTasks() {
    const tasksString = localStorage.getItem("tasks");
    return tasksString ? JSON.parse(tasksString) : [];
}

function saveTasks(tasks) {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}